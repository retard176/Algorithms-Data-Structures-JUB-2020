#include <iostream>
#include <bits/stdc++.h>

using namespace std;


class PuzzleBoard {
private:
int size;
int **
public:
	PuzzleBoard(int boardSize, int[][] fields = null) {
		size = boardSize;
	}
}